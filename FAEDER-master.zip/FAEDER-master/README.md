✟︙لتنصيب سورس فايدر ، FAEDER ،

• ┉ • ┉ • ┉ • ┉ • ┉ • ┉ • ┉ •
         
✟︙ اتبع الخطوات ادناه :-


✟︙ انسخ الكود وضعه في الترمنال ،

✟︙ الكود ،

git clone https://github.com/TEAMFAEDER/FAEDER.git && cd FAEDER  && chmod +x tg && chmod +x RUNFA.sh && chmod +x FA && ./RUNFA.sh

• ┉ • ┉ • ┉ • ┉ • ┉ • ┉ • ┉ •

✟︙راح يطلب المعلومات التاليه :- 

✟︙{ ايدي المطور  • معرف المطور • توكن البوت } ،

✟︙قم بادخال معلوماتك سوف يعمل تلقائيا ،

• ┉ • ┉ • ┉ • ┉ • ┉ • ┉ • ┉ •

✟︙كود الرن ، 

killall screen;cd FAEDER;./FA

✟︙كود الحذف ، 

rm -rf FAEDER

• ┉ • ┉ • ┉ • ┉ • ┉ • ┉ • ┉ •

✟︙للاستفسار واضافه الافكار  🔽

✟︙ مبرمج السورس @kkkkf 

✟︙ قناة السورس @faeder_ch

✟︙ كروب الدعم https://t.me/joinchat/TXKJWVCCy9FF6g6cjajRGA
